import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as L from 'leaflet';
import { Chart,ChartOptions, ChartData, ChartType } from 'chart.js/auto';
import { Color } from '@swimlane/ngx-charts';
import { ScaleType } from '@swimlane/ngx-charts';
import ChartDataLabels from 'chartjs-plugin-datalabels';


@Component({
  selector: 'app-dadtwo-dashboard',
  templateUrl: './dadtwo-dashboard.component.html',
  styleUrl: './dadtwo-dashboard.component.scss'
})
export class DadtwoDashboardComponent {


  searchTerm: string = '';
  // Header Cards
  headerCards = [
    { title: 'Total Number of Cases', value:1000 },
    { title: 'Total Number of Cases Register Before “DATE”', value:1000 },
    { title: 'Total Number of Cases Register Before “DATE”', value:1000 },
  ];

   // Red Zone Cards
   redZoneCards = [
    { title: 'Cases pending for more than 7 days', value: 1000 },
    { title: 'Cases pending for more than 60 days', value: 1000 },
    { title: 'Cases pending for more than 90 days', value: 1000 },
  ];

  // Red Zone Cases
  redZoneCases = [
    { firNo: '01/2024', district: 'Trichy', pendingDays: 6, status: 'Pending 1st Relief', firstReliefGiven: false, priority: 'High', nextActionDue: 'Within 1 Day' },
    { firNo: '02/2024', district: 'Trichy', pendingDays: 5, status: 'Pending 1st Relief', firstReliefGiven: false, priority: 'Medium', nextActionDue: 'Within 2 Days' },
    { firNo: '04/2024', district: 'Trichy', pendingDays: 7, status: 'Red Zone', firstReliefGiven: false, priority: 'Critical', nextActionDue: 'Immediate' },
    { firNo: '07/2024', district: 'Trichy', pendingDays: 4, status: 'Pending', firstReliefGiven: true, priority: 'Low', nextActionDue: 'N/A' },
  ];

  // Semi-circle circumference
  cards = [
    { title: 'Job Given', percentage: 24, total: 1000, status: 'given' },
    { title: 'Pension Given', percentage: 24, total: 1000, status: 'given' },
    { title: 'Patta Given', percentage: 24, total: 1000, status: 'given' },
    { title: 'Education Concession Given', percentage: 24, total: 1000, status: 'given' },
    { title: 'Job Pending', percentage: 76, total: 1000, status: 'pending' },
    { title: 'Pension Pending', percentage: 76, total: 1000, status: 'pending' },
    { title: 'Patta Pending', percentage: 76, total: 1000, status: 'pending' },
    { title: 'Education Concession Pending', percentage: 76, total: 1000, status: 'pending' },
  ];

   
  getStrokeDashArray(percentage: number): string {
    const circumference = Math.PI * 40;
    const progress = (percentage / 100) * circumference;
    return `${progress} ${circumference - progress}`;
  }

  statistics = [
    {
      description: 'Total Number of Cases pending for more than 7 days',
      value: 2000,
      iconAlt: 'Pending Cases Icon'
    },
    {
      description: 'Total Number of Cases pending for more than 60 days',
      value: 3000,
      iconAlt: 'Pending Cases Icon'
    },
    {
      description: 'Total Number of Cases pending for more than 90 days',
      value: 5000,
      iconAlt: 'Pending Cases Icon'
    }
  ];

  @ViewChild('pieChart') pieChart!: ElementRef;


  createPieChart(): void {
    new Chart("pieChart", {
      type: 'pie',
      data: {
        labels: ['Relief Pending', 'Relief Given'],
        datasets: [
          {
            data: [60, 40], // Adjust the values here
            backgroundColor: ['#007bff', '#ADD8E6'], // Colors for the chart segments
            hoverBackgroundColor: ['#0056b3', '#7ec0ee'], // Hover effect colors
            borderWidth: 1
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false // Hides default legend
          },
          tooltip: {
            callbacks: {
              label: (context) => `${context.label}: ${context.raw}%`
            }
          }
        }
      }
    });
  }


  selectedFilter = 'Job';


  updateFilter() {
    console.log('Filter changed to:', this.selectedFilter);
  }



  ngAfterViewInit() {

    const districtNames = [
      'Madurai', 'Thirunelveli', 'Thiruvannamalai', 'Thanjavur',
      'Sivagangai', 'Thenkasi', 'Theni', 'Salem',
      'Cuddalore', 'Vilupuram', 'Coimbatore', 'Erode',
      'Tiruvarur', 'Namakkal', 'Krishnagiri'
    ];
    const caseCounts = [20, 30, 40, 20, 2, 10, 45, 97, 57, 59, 38, 52, 64, 42, 64];

    new Chart('districtBarChart', {
      type: 'bar',
      data: {
        labels: districtNames,
        datasets: [
          {
            label: 'Cases',
            data: caseCounts,
            backgroundColor: '#36b9cc',
            borderColor: '#2c9faf',
            borderWidth: 1
          }
        ]
      },
      options: {
        indexAxis: 'y', // Horizontal bar chart
        responsive: true,
        plugins: {
          legend: {
            display: false // Hides the dataset label
          }
        },
        scales: {
          x: {
            beginAtZero: true // Ensures x-axis starts from 0
          }
        }
      }
    });

    new Chart('districtBarChart1', {
      type: 'bar',
      data: {
        labels: districtNames,
        datasets: [
          {
            label: 'Cases',
            data: caseCounts,
            backgroundColor: '#36b9cc',
            borderColor: '#2c9faf',
            borderWidth: 1
          }
        ]
      },
      options: {
        indexAxis: 'y', // Horizontal bar chart
        responsive: true,
        plugins: {
          legend: {
            display: false // Hides the dataset label
          }
        },
        scales: {
          x: {
            beginAtZero: true // Ensures x-axis starts from 0
          }
        }
      }
    });

    this.createPieChart();
   
  }
  
}
